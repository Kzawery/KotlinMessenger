package com.example.kmessenger

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_login.*
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class LoginActivity: AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        login_button_login.setOnClickListener {
            val email = email_textedit_login.text.toString()
            val password = password_textview_login.text.toString()

            if(email.isEmpty() || password.isEmpty()){
                Toast.makeText(this,"Enter data", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            else {

            }

        }




    }

}